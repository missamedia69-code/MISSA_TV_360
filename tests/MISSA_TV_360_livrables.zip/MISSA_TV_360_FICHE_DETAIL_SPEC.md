# MISSA TV 360 — Fiche détail (à implémenter)

> Destinataire : agent de code. Dépôt : `missamedia69-code/MISSA_TV_360`, branche `arena/ca646cf9-missa-tv-360`. Package `com.missa.tv360`, Kotlin, Leanback 1.0, minSdk 21.
> **Périmètre : uniquement la fiche détail** (`ui/DetailsFragment.kt` et l'écran qui l'héberge). Ne pas toucher à l'écran d'accueil.
> **Avant de coder, lire** : `ui/DetailsFragment.kt`, `data/Video.kt`, `playback/PlayerActivity.kt`, `res/values/colors.xml`, `res/values/themes.xml`.
> Maquette : artboard « Fiche détail — NASA TV Public » sur https://claude.ai/artifact/UnULdjHqAdj9bDbDUmBZjt

## 1. Problèmes de la version actuelle

- Zone vide d'environ 290 px en haut, aucun fond.
- Visuel minuscule (200×112) affichant le repli « À connecter BFF ».
- Un seul bouton gris sur gris, en majuscules Roboto condensed, contraste faible.
- Titre fin, métadonnées sur une ligne, description petite, pas de badge LIVE.
- Ni source, ni licence, ni contenus associés, ni « Ma liste ».

## 2. Règles

- Aucune nouvelle dépendance. Réutiliser `ThumbnailLoader` et `defaultCardFor(kind)`.
- Ne pas casser `./gradlew :app:assembleDebug` ni `python -m unittest discover -s tests`.
- Tout est focusable au D-pad, avec `contentDescription`.
- Le TV 1080p fait 960×540 dp. Les valeurs ci-dessous sont en dp/sp. Textes ≥ 12sp.

## 3. Jetons à ajouter (sans doublon avec l'existant)

```xml
<!-- colors.xml -->
<color name="missa_bg_top">#0A1633</color>
<color name="missa_bg_bottom">#060E22</color>
<color name="missa_yellow">#FAE504</color>
<color name="missa_live">#E02020</color>
<color name="missa_text">#E8EDFA</color>
<color name="missa_text_secondary">#C7D1EA</color>
<color name="missa_on_yellow">#0A1633</color>
```

```xml
<!-- strings.xml -->
<string name="action_watch_live">Regarder en direct</string>
<string name="action_play">Lire</string>
<string name="action_listen">Écouter</string>
<string name="action_my_list_add">+ Ma liste</string>
<string name="action_my_list_remove">✓ Dans ma liste</string>
<string name="action_report">Signaler un problème</string>
<string name="details_similar">Chaînes similaires</string>
<string name="details_source">Source : %1$s</string>
```

## 4. Structure de l'écran

| Zone | Position / taille | Contenu |
|---|---|---|
| Fond | plein écran | `BackgroundManager` : visuel du contenu (`cardUrl`), dégradé horizontal marine → transparent (0 à 80 % de la largeur), dégradé vertical vers le bas |
| Fil d'Ariane | x 48, y 20 | Flèche retour, « Catégorie › Titre » (14sp ; le titre en blanc gras) |
| Visuel | x 48, y 57, 264×148 | Coins 12dp, ombre, badge LIVE en haut à gauche si direct, bouton lecture rond (36dp) centré |
| Badges | x 339, y 52 | EN DIRECT (rouge, 12sp gras) si direct, puis catégorie, HD, licence ; contour blanc 35 %, coins 5dp |
| Titre | sous les badges | 34sp, poids 800 |
| Description | sous le titre | 16sp, `missa_text_secondary`, 3 lignes max, largeur 450dp |
| Source | sous la description | 13sp : « Source : NASA · Flux HLS public » |
| Actions | sous la source | **Regarder en direct** (jaune, icône lecture), **+ Ma liste**, **Signaler un problème** |
| Ligne similaires | y 294 | Titre de ligne avec barre jaune, cartes 16:9 (136×76dp) |

Libellé du bouton principal : « Regarder en direct » pour les contenus en direct, « Écouter » pour la radio et les podcasts, « Lire » pour le reste. Pas de majuscules forcées.

## 5. Comportement

1. **Focus initial** sur le bouton principal.
2. **Focus d'un bouton** : zoom 1,05 en 120 ms ; le bouton principal affiche en plus une bordure blanche de 3dp.
3. **Ma liste** : stockage local (`MyListStore`, SharedPreferences, ensemble d'ids). Le libellé bascule entre ajout et retrait.
4. **Signaler un problème** : écran simple (liste de motifs : flux coupé, mauvais contenu, droits) qui enregistre le `videoId` et le motif ; pour l'instant, stockage local et envoi différé.
5. **Source et licence** : lues dans les métadonnées du `Video` (ajouter `source: String?` et `license: String?` si absents, valeurs `null` tolérées). Si `license` est vide pour un film, ne pas afficher de badge « Domaine public ».
6. **Contenus similaires** : `FilmSourceRegistry.related()` pour les films, même catégorie pour les chaînes. Masquer la ligne s'il y a moins de 3 résultats.
7. **Navigation** : retour télécommande ramène à la grille sans la recharger. Si la fiche est une `DetailsActivity`, la grille reste dans la pile précédente.
8. **Visuel absent** : ne jamais appeler `getDrawable(0)`. Utiliser `cardUrl`, puis `defaultCardFor(kind)`.

## 6. Code

### 6.1 Action et présentateur de bouton

```kotlin
data class MissaAction(val id: Long, val label: String, @DrawableRes val iconRes: Int, val primary: Boolean)

class MissaActionPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val b = LayoutInflater.from(parent.context).inflate(R.layout.action_button, parent, false)
        b.setOnFocusChangeListener { v, focused ->
            v.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(120).start()
        }
        return ViewHolder(b)
    }

    override fun onBindViewHolder(vh: ViewHolder, item: Any) {
        val a = item as MissaAction
        (vh.view as Button).apply {
            text = a.label
            setCompoundDrawablesWithIntrinsicBounds(a.iconRes, 0, 0, 0)
            setBackgroundResource(if (a.primary) R.drawable.bg_btn_primary else R.drawable.bg_btn_secondary)
            setTextColor(ContextCompat.getColor(context,
                if (a.primary) R.color.missa_on_yellow else R.color.missa_text))
        }
    }
    override fun onUnbindViewHolder(vh: ViewHolder) {}
}
```

### 6.2 Libellé du bouton principal

```kotlin
fun primaryLabel(kind: ContentKind, ctx: Context) = when {
    kind.isLive -> ctx.getString(R.string.action_watch_live)
    kind.isAudioOnly -> ctx.getString(R.string.action_listen)
    else -> ctx.getString(R.string.action_play)
}
```

### 6.3 Layout du bouton `res/layout/action_button.xml`

```xml
<Button xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="wrap_content" android:layout_height="40dp"
    android:minWidth="0dp" android:paddingHorizontal="18dp"
    android:drawablePadding="8dp" android:textAllCaps="false"
    android:textSize="16sp" android:textStyle="bold" android:focusable="true"
    android:stateListAnimator="@null" />
```

### 6.4 Fonds de boutons

- `bg_btn_primary.xml` : sélecteur. Normal : fond `missa_yellow`, coins 8dp. Focalisé : même fond + `stroke` blanc de 3dp.
- `bg_btn_secondary.xml` : sélecteur. Normal : fond blanc 10 %, `stroke` 2dp blanc 35 %. Focalisé : fond blanc 20 %, `stroke` 2dp jaune.

### 6.5 Fond et dégradés

```kotlin
private val bg by lazy { BackgroundManager.getInstance(requireActivity()).apply { attach(requireActivity().window) } }

fun applyBackdrop(video: Video) {
    ThumbnailLoader.loadDrawable(requireContext(), video.cardUrl, defaultCardFor(video.kind)) { d ->
        bg.drawable = LayerDrawable(arrayOf(
            d,
            ContextCompat.getDrawable(requireContext(), R.drawable.scrim_horizontal), // marine → transparent
            ContextCompat.getDrawable(requireContext(), R.drawable.scrim_vertical)    // transparent → marine
        ))
    }
}
```

### 6.6 Badge LIVE

```xml
<!-- bg_badge_live.xml -->
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="@color/missa_live" />
    <corners android:radius="4dp" />
</shape>
```

## 7. Critères d'acceptation

- [ ] Plus de zone vide : fond, visuel et titre occupent le haut de l'écran.
- [ ] Le bouton principal est jaune, lisible (contraste ≥ 4,5:1) et focalisé par défaut.
- [ ] Le badge LIVE n'apparaît que pour les contenus en direct.
- [ ] Source (et licence pour les films) visibles sur chaque fiche.
- [ ] La ligne « similaires » est masquée quand il y a moins de 3 contenus.
- [ ] « Ma liste » ajoute et retire un contenu, et l'état persiste après redémarrage.
- [ ] « Signaler un problème » ouvre l'écran de motifs et enregistre le `videoId`.
- [ ] Aucun crash si `cardUrl` est absent ou si le réseau est coupé.
- [ ] `assembleDebug` vert, tests Python verts, un test Kotlin sur `primaryLabel`.

## 8. Ordre de travail

1. Jetons et chaînes, `action_button.xml`, fonds de boutons.
2. `MissaActionPresenter` et boutons principal et secondaires.
3. Fond (`BackgroundManager`) et dégradés.
4. Badges, titre, description, source.
5. `MyListStore` et « Ma liste ».
6. Ligne « similaires ».
7. Écran « Signaler un problème ».
