# MISSA TV 360 — Spécification de l'écran d'accueil (à implémenter)

> Destinataire : agent de code. Dépôt : `missamedia69-code/MISSA_TV_360`, branche de travail `arena/ca646cf9-missa-tv-360`.
> Package : `com.missa.tv360`. Stack : Kotlin, Android TV, Leanback 1.0, minSdk 21.
> **Avant de coder, lire** : `ui/BrowseFragment.kt`, `ui/CardPresenter.kt`, `ui/BrandCardFocus.kt`, `ui/DetailsFragment.kt`, `data/Video.kt`, `res/values/colors.xml`, `res/values/themes.xml`. Réutiliser ce qui existe, ne rien dupliquer.

## 0. Règles

- Aucune nouvelle dépendance lourde. Coil est autorisé uniquement pour les vignettes (cache disque).
- Ne pas casser `./gradlew :app:assembleDebug` ni `python -m unittest discover -s tests`.
- Tout élément interactif est focusable à la télécommande (D-pad) et possède un `contentDescription`.
- La maquette est dessinée sur un canevas 1280×720. Un téléviseur 1080p fait 960×540 dp : **dp = px maquette × 0,75**. Les valeurs ci-dessous sont déjà en dp/sp, avec des textes relevés pour être lisibles à 3 m.

## 1. Jetons de design

`res/values/colors.xml` (fusionner avec les couleurs existantes, ne pas créer de doublons) :

```xml
<color name="missa_bg_top">#0A1633</color>      <!-- marine -->
<color name="missa_bg_bottom">#060E22</color>
<color name="missa_yellow">#FAE504</color>      <!-- focus, accent, bouton principal -->
<color name="missa_blue">#0142AB</color>
<color name="missa_green">#00A030</color>
<color name="missa_live">#E02020</color>
<color name="missa_text">#E8EDFA</color>
<color name="missa_text_secondary">#C7D1EA</color>
<color name="missa_on_yellow">#0A1633</color>
```

`res/values/dimens.xml` :

```xml
<dimen name="screen_margin">48dp</dimen>
<dimen name="topbar_height">40dp</dimen>
<dimen name="card16_w">136dp</dimen><dimen name="card16_h">76dp</dimen>
<dimen name="poster_w">84dp</dimen><dimen name="poster_h">126dp</dimen>
<dimen name="square">90dp</dimen>
<dimen name="card_gap">12dp</dimen>
<dimen name="card_radius">8dp</dimen>
<dimen name="focus_stroke">3dp</dimen>
<dimen name="progress_h">3dp</dimen>
```

Typographie : famille **Outfit** (poids 400/600/700/800) dans `res/font/`, repli `sans-serif`. Échelle : titre héro 34sp/800, titre de ligne 18sp/600, légende de carte 14sp/400, badge 12sp/700, bouton 16sp/700.

## 2. Structure de l'écran (de haut en bas)

| Zone | y (dp) | Contenu |
|---|---|---|
| Barre du haut | 16 → 56 | Logo à gauche (pastille jaune « MISSA » + « TV 360 », « 360 » en vert), onglets centraux (Accueil, TV Direct, Films, Séries, Musique, Jeux), boutons ronds Recherche et Paramètres à droite |
| Héro « À la une » | 62 → 210 | Texte à gauche (largeur 420), visuel à droite (250×177, coins 12dp, ombre), dégradé horizontal marine → transparent par-dessus |
| Ligne 1 « Reprendre » | 222 → 342 | Cartes 16:9 avec barre de progression jaune, une carte LIVE |
| Ligne 2 « Films populaires » | 350 → 520 | Affiches 2:3 |
| Ligne 3 « Radio & Podcasts » | à partir de 528 | Vignettes carrées, **volontairement coupée** par le bas de l'écran |

Fond : dégradé diagonal `missa_bg_top` → `missa_bg_bottom`, plus un halo radial bleu `#1b3f9a` en haut à droite. Dégradé de fondu de 27dp en bas de l'écran.

Contenu du héro : surtitre « À LA UNE » (12sp, jaune, espacement 1,4), puis badges contour blanc (« Domaine public », « HD », « année · durée »), puis titre, résumé (16sp, max 2 lignes), puis boutons **Lire** (plein jaune, texte marine, bordure blanche 3dp quand focalisé), **+ Ma liste** et **Détails** (contour blanc 35 %).

## 3. Comportement

1. **Focus carte** : bordure `missa_yellow` 3dp, `scaleX/scaleY` 1,07 en 120 ms, élévation 8dp, légende en jaune et gras. Pas de fond vert. Un seul style pour tous les formats.
2. **Héro dynamique** : quand une carte reçoit le focus, le héro (titre, badges, résumé, visuel) et le fond d'écran (`BackgroundManager`) se mettent à jour avec un fondu de 200 ms. Anti-rebond de 150 ms pour ne pas charger une image à chaque défilement.
3. **Formats par type** (`ContentKind`) :
   - 16:9 → `LIVE_TV`, `LIVE_SPORT`, `SHORT`, reprises de lecture
   - 2:3 → `MOVIE`, `SERIES`
   - 1:1 → `RADIO`, `PODCAST`, `MUSIC`, `GAME`
4. **Badges** : `LIVE` (rouge, coin haut gauche), `HD`, `NOUVEAU`. Barre de progression en bas de carte pour les contenus commencés.
5. **Reprendre** : nouvelle ligne alimentée par `WatchProgressStore` (SharedPreferences : `videoId → positionMs, durationMs, updatedAt`). `PlayerActivity.onPause` y écrit la position. Afficher seulement si 3 % < avancement < 95 %, trié par `updatedAt` décroissant, 10 entrées maximum.
6. **Chargement** : cartes squelettes grises avec shimmer à la place du spinner. **Erreur / hors-ligne** : message centré + bouton « Réessayer ». Dans les deux cas, afficher le dernier catalogue en cache s'il existe.
7. **Navigation** : Browse → Details via une `DetailsActivity` dédiée (plus de `replace` + back stack). Le catalogue est tenu dans un `ViewModel` pour éviter le rechargement au retour.

## 4. Squelettes de code

### 4.1 Forme des cartes

```kotlin
enum class CardShape(val widthRes: Int, val heightRes: Int) {
    LANDSCAPE(R.dimen.card16_w, R.dimen.card16_h),
    POSTER(R.dimen.poster_w, R.dimen.poster_h),
    SQUARE(R.dimen.square, R.dimen.square);

    companion object {
        fun forKind(kind: ContentKind) = when (kind) {
            ContentKind.MOVIE, ContentKind.SERIES -> POSTER
            ContentKind.RADIO, ContentKind.PODCAST, ContentKind.MUSIC, ContentKind.GAME -> SQUARE
            else -> LANDSCAPE
        }
    }
}
```

### 4.2 Présentateur unique

```kotlin
class MissaCardPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.card_missa, parent, false)
        v.isFocusable = true
        v.isFocusableInTouchMode = true
        v.setOnFocusChangeListener { view, focused ->
            view.animate().scaleX(if (focused) 1.07f else 1f)
                .scaleY(if (focused) 1.07f else 1f).setDuration(120).start()
            view.elevation = if (focused) 8f * view.resources.displayMetrics.density else 0f
            view.findViewById<TextView>(R.id.card_title)
                .setTextColor(ContextCompat.getColor(view.context,
                    if (focused) R.color.missa_yellow else R.color.missa_text_secondary))
        }
        return ViewHolder(v)
    }

    override fun onBindViewHolder(vh: ViewHolder, item: Any) {
        val video = item as Video
        val v = vh.view
        val shape = CardShape.forKind(video.kind)
        val image = v.findViewById<ImageView>(R.id.card_image)
        image.layoutParams = image.layoutParams.apply {
            width = v.resources.getDimensionPixelSize(shape.widthRes)
            height = v.resources.getDimensionPixelSize(shape.heightRes)
        }
        v.findViewById<TextView>(R.id.card_title).text = video.title
        v.findViewById<View>(R.id.badge_live).isVisible = video.kind.isLive
        v.findViewById<ProgressBar>(R.id.card_progress).apply {
            val p = WatchProgressStore.fraction(v.context, video.id)
            isVisible = p != null
            progress = ((p ?: 0f) * 100).toInt()
        }
        // Vignette : cardUrl via le chargeur existant, repli sur defaultCardFor(kind)
        ThumbnailLoader.load(image, video.cardUrl, fallback = defaultCardFor(video.kind))
    }

    override fun onUnbindViewHolder(vh: ViewHolder) {
        vh.view.findViewById<ImageView>(R.id.card_image).setImageDrawable(null)
    }
}
```

### 4.3 Layout `res/layout/card_missa.xml`

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="wrap_content" android:layout_height="wrap_content"
    android:orientation="vertical" android:clipChildren="false">

    <FrameLayout android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:background="@drawable/bg_card_focus">  <!-- sélecteur : stroke 3dp jaune si focused -->
        <ImageView android:id="@+id/card_image" android:layout_width="136dp"
            android:layout_height="76dp" android:scaleType="centerCrop" />
        <TextView android:id="@+id/badge_live" android:layout_width="wrap_content"
            android:layout_height="wrap_content" android:layout_margin="6dp"
            android:background="@drawable/bg_badge_live" android:text="LIVE"
            android:textColor="#FFFFFF" android:textSize="12sp" android:textStyle="bold"
            android:paddingHorizontal="6dp" android:visibility="gone" />
        <ProgressBar android:id="@+id/card_progress" style="?android:attr/progressBarStyleHorizontal"
            android:layout_width="match_parent" android:layout_height="@dimen/progress_h"
            android:layout_gravity="bottom" android:progressTint="@color/missa_yellow"
            android:visibility="gone" />
    </FrameLayout>

    <TextView android:id="@+id/card_title" android:layout_width="136dp"
        android:layout_height="wrap_content" android:layout_marginTop="6dp"
        android:maxLines="1" android:ellipsize="end" android:textSize="14sp"
        android:textColor="@color/missa_text_secondary" />
</LinearLayout>
```

### 4.4 Héro en première ligne Leanback

```kotlin
class HeroRow(val video: Video) : Row()          // une seule instance, mise à jour au focus

class HeroRowPresenter : RowPresenter() {
    init { headerPresenter = null; selectEffectEnabled = false }
    // Inflate hero_row.xml : tag(s), titre, résumé, boutons Lire / Ma liste / Détails, visuel à droite.
    // Exposer fun bind(video: Video) appelé par BrowseFragment.onItemSelected, avec anti-rebond 150 ms.
}
```

Dans `BrowseFragment` :

```kotlin
private val bg by lazy { BackgroundManager.getInstance(requireActivity()).apply { attach(requireActivity().window) } }
private val heroDebounce = Handler(Looper.getMainLooper())

onItemViewSelectedListener = OnItemViewSelectedListener { _, item, _, _ ->
    val v = item as? Video ?: return@OnItemViewSelectedListener
    heroDebounce.removeCallbacksAndMessages(null)
    heroDebounce.postDelayed({ heroPresenter.bind(v); bg.drawable = backdropFor(v) }, 150)
}
```

### 4.5 Barre du haut

Phase A (rapide) : garder les en-têtes Leanback actuels. Phase B : `headersState = HEADERS_HIDDEN` et un `TopBarView` (LinearLayout horizontal) placé au-dessus du conteneur du fragment dans `activity_main.xml`. Onglet actif : texte jaune gras + soulignement 3dp. Le D-pad haut depuis la première ligne donne le focus à la barre.

### 4.6 Persistance de la progression

```kotlin
object WatchProgressStore {
    fun save(ctx: Context, id: String, pos: Long, dur: Long) { /* SharedPreferences "watch_progress" */ }
    fun fraction(ctx: Context, id: String): Float? { /* pos/dur, ou null si absent */ }
    fun recent(ctx: Context, limit: Int = 10): List<String> { /* ids triés par updatedAt desc */ }
}
```

## 5. Critères d'acceptation

- [ ] Les trois formats de cartes (16:9, 2:3, 1:1) s'affichent selon `ContentKind`.
- [ ] Le focus applique le même style partout : bordure jaune, zoom 1,07, légende jaune.
- [ ] Le héro et le fond changent au focus, sans saccade.
- [ ] La ligne « Reprendre » apparaît après la lecture partielle d'un contenu.
- [ ] Hors-ligne, le dernier catalogue en cache s'affiche, avec un bouton « Réessayer » en cas d'échec.
- [ ] Retour depuis la fiche : pas de rechargement ni de lignes vides.
- [ ] Aucun texte sous 12sp. Contraste ≥ 4,5:1 (jaune sur marine, `missa_text_secondary` sur marine).
- [ ] `assembleDebug` vert, tests Python verts, un test Kotlin ajouté pour `CardShape.forKind` et `WatchProgressStore.fraction`.

## 6. Ordre de travail conseillé

1. Jetons (couleurs, dimensions, police) et `card_missa.xml`.
2. `MissaCardPresenter` + `CardShape`, branchés dans `BrowseFragment`.
3. `WatchProgressStore` + ligne « Reprendre ».
4. `HeroRow` + `BackgroundManager`.
5. `DetailsActivity` + `ViewModel` du catalogue.
6. Squelettes de chargement, états erreur et hors-ligne.
7. Barre du haut personnalisée (phase B).

---

# 7. Fiche détail (DetailsActivity) — à améliorer

Maquette : deuxième artboard « Fiche détail — NASA TV Public » du même canevas.

## 7.1 Défauts de la version actuelle (capture)

- Zone vide d'environ 290 px au-dessus du contenu, pas de fond.
- Visuel minuscule (200×112) avec le repli « À connecter BFF ».
- Un seul bouton gris sur gris, en majuscules Roboto condensed, contraste faible.
- Titre fin, métadonnées sur une ligne, description petite, pas de badge LIVE.
- Aucune source ni licence, aucun contenu associé, aucune action « Ma liste ».

## 7.2 Structure cible (dp, TV 1080p = 960×540)

| Zone | Contenu |
|---|---|
| Fond | `BackgroundManager` : visuel du contenu, dégradé horizontal marine → transparent, dégradé vertical vers le bas |
| Fil d'Ariane (y 20) | Flèche retour, « TV Direct › NASA TV Public » (14sp) |
| Visuel (x 48, y 57) | 264×148, coins 12dp, ombre, badge LIVE en haut à gauche, bouton lecture centré (36dp) |
| Infos (x 339, y 52) | Ligne de badges (EN DIRECT rouge, catégorie, HD, licence), titre 34sp/800, description 16sp (2 à 3 lignes), ligne source 13sp |
| Actions | **Regarder en direct** (jaune, icône lecture, bordure blanche au focus), **+ Ma liste**, **Signaler un problème** |
| Ligne « Chaînes similaires » (y 294) | Cartes 16:9 avec badge LIVE, issues de `FilmSourceRegistry.related()` ou, pour les chaînes, de la même catégorie |

Libellés : « Regarder en direct » pour `LIVE_*`, « Lire » pour les films, « Écouter » pour la radio et les podcasts. Plus de majuscules forcées.

## 7.3 Code

```kotlin
// Remplace l'actions row grise par des boutons personnalisés.
class MissaActionPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val b = LayoutInflater.from(parent.context).inflate(R.layout.action_button, parent, false)
        b.setOnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(120).start()
        }
        return ViewHolder(b)
    }
    override fun onBindViewHolder(vh: ViewHolder, item: Any) {
        val a = item as MissaAction            // data class MissaAction(id, label, iconRes, primary)
        (vh.view as Button).apply {
            text = a.label
            setCompoundDrawablesWithIntrinsicBounds(a.iconRes, 0, 0, 0)
            setBackgroundResource(if (a.primary) R.drawable.bg_btn_primary else R.drawable.bg_btn_secondary)
            setTextColor(ContextCompat.getColor(context, if (a.primary) R.color.missa_on_yellow else R.color.missa_text))
        }
    }
    override fun onUnbindViewHolder(vh: ViewHolder) {}
}
```

```kotlin
// Libellé du bouton principal selon le type
fun primaryLabel(kind: ContentKind, ctx: Context) = when {
    kind.isLive -> ctx.getString(R.string.action_watch_live)   // « Regarder en direct »
    kind.isAudioOnly -> ctx.getString(R.string.action_listen)  // « Écouter »
    else -> ctx.getString(R.string.action_play)                // « Lire »
}
```

## 7.4 Critères d'acceptation

- [ ] Plus de zone vide : fond, visuel et titre occupent le haut de l'écran.
- [ ] Le bouton principal est jaune, lisible (contraste ≥ 4,5:1) et focalisé par défaut.
- [ ] Le badge LIVE s'affiche pour les contenus en direct, et seulement pour eux.
- [ ] Source et licence visibles sur chaque fiche (obligatoire pour les contenus du domaine public).
- [ ] La ligne « similaires » s'affiche si au moins 3 contenus correspondent, sinon elle est masquée.
- [ ] « Ma liste » fonctionne (stockage local), « Signaler un problème » ouvre un écran simple avec envoi du `videoId`.
- [ ] Retour télécommande : revient à la grille sans la recharger.
