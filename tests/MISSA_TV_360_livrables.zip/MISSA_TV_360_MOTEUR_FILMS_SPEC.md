# MISSA TV 360 — Moteur Films natif + paquets de livraison GitHub

> Destinataire : tout agent de code qui reprend le dépôt `missamedia69-code/MISSA_TV_360` (branche `arena/ca646cf9-missa-tv-360`).
> **Avant de coder, lire** : `engines/films/manifest.json`, `engines/films/engine.py`, `engines/_core/schema.py`, `app/src/main/java/com/missa/tv360/data/source/*` (`FilmSource`, `InternetArchiveFilmSource`, `FilmEngineRepository`, `FilmEngineManifest`), `data/Video.kt`, `ui/BrowseFragment.kt`, `ui/DetailsFragment.kt`.
> Ce document **étend** l'existant, il ne le remplace pas : le moteur Films natif et son manifeste existent déjà.

## 1. Principe

1. Le **moteur vit dans l'application** (Kotlin). Il sait chercher, classer, dédupliquer, enrichir, mettre en cache et servir les films.
2. Les dossiers `engines/<moteur>/` du dépôt deviennent des **paquets de livraison** : l'agent IA y dépose des sources brutes affinées et la **méthodologie d'acquisition** (recettes déclaratives).
3. L'application **consulte automatiquement** le dépôt (via GitHub Pages), télécharge les paquets modifiés, les **valide**, puis applique la nouvelle méthodologie sans mise à jour de l'APK.
4. **Règle d'or de sécurité : un paquet distant contient des données et des paramètres, jamais de code exécutable.** Les nouveaux types de source passent par un adaptateur natif, donc par une mise à jour de l'app.

## 2. Contenu d'un paquet `engines/films/`

```
engines/films/
├── manifest.json            # identité, version, politique, liste des sources
├── sources/
│   ├── internet_archive.json
│   └── <autre_source>.json  # une recette par source
├── editorial/
│   ├── featured.json        # à la une, ordre voulu
│   ├── collections.json     # listes thématiques (ids de films)
│   └── similar_overrides.json  # "films semblables" imposés (optionnel)
├── rules/
│   ├── rights.json          # collections et licences autorisées
│   └── blocklist.json       # ids retirés immédiatement
├── seed/films_seed.json     # petit jeu embarqué pour le premier lancement hors-ligne
└── CHANGELOG.md
```

### 2.1 `manifest.json` (schema_version 2)

```json
{
  "schema_version": 2,
  "engine_id": "films",
  "version": 12,
  "updated_at": "2026-10-20",
  "min_app_version": 4,
  "languages": ["fr", "en"],
  "policy": {
    "https_only": true,
    "allowed_hosts": ["archive.org", "ia800000.us.archive.org"],
    "require_rights": ["public_domain", "cc"],
    "hide_unknown_rights": true
  },
  "sources": ["sources/internet_archive.json"],
  "editorial": ["editorial/featured.json", "editorial/collections.json"],
  "rules": ["rules/rights.json", "rules/blocklist.json"]
}
```

### 2.2 Recette de source (exemple Internet Archive)

```json
{
  "id": "internet_archive",
  "adapter": "internet_archive",
  "enabled": true,
  "query": {
    "collections": ["feature_films", "silent_films", "classic_cinema"],
    "exclude_collections": [],
    "media_type": "movies"
  },
  "trending": { "sort": "downloads desc", "limit": 24 },
  "search":   { "fields": ["title", "creator", "subject"], "limit": 40 },
  "formats":  { "playable": ["mp4"], "quality_order": "height_then_size" },
  "mapping": {
    "title": "title", "year": "year", "synopsis": "description",
    "genres": "subject", "director": "creator", "license": "licenseurl"
  }
}
```

Adaptateurs natifs à prévoir (chacun reçoit une recette, aucun ne charge de code distant) :

| Adaptateur | Usage |
|---|---|
| `internet_archive` | Existant. À durcir (filtre de droits, voir §6) |
| `json_api` | API JSON quelconque : URL à gabarit + correspondance de champs (JSONPath simple) |
| `static_list` | Liste éditée à la main par l'agent (titre, flux, affiche, droits) |
| `rss` / `m3u` | Flux de listes pour des chaînes de films ou des catalogues |

## 3. Modèle normalisé `Film` (sans ambiguïté)

```kotlin
data class Film(
    val id: String,              // stable : "<source_id>:<id_source>"
    val canonicalKey: String,    // titre normalisé + année, sert à fusionner les doublons
    val title: String,
    val originalTitle: String?,
    val year: Int?,
    val durationMin: Int?,
    val synopsis: String?,
    val synopsisLang: String?,   // "fr", "en"… jamais deviné en silence
    val genres: List<String>,    // vocabulaire contrôlé (voir §3.1)
    val countries: List<String>,
    val director: String?,
    val cast: List<String>,
    val posterUrl: String?,      // 2:3
    val backdropUrl: String?,    // 16:9
    val streams: List<Stream>,   // classés du meilleur au plus léger
    val subtitles: List<Subtitle>,
    val rights: Rights,
    val source: SourceRef,
    val popularity: Float,       // 0..1 normalisé par source
    val addedAt: String?
)
data class Stream(val url: String, val type: String /* mp4|hls */, val height: Int?, val sizeMb: Int?)
data class Subtitle(val lang: String, val url: String)
data class Rights(val status: String /* public_domain|cc|licensed|unknown */, val license: String?, val evidenceUrl: String?)
data class SourceRef(val id: String, val name: String, val pageUrl: String?)
```

### 3.1 Règles qui évitent l'ambiguïté

- **Identité** : `canonicalKey = normalize(title) + "|" + year`, où `normalize` retire accents, casse, ponctuation et articles initiaux. Deux films de même clé sont fusionnés ; on garde les flux de toutes les sources, la meilleure affiche et la meilleure description.
- **Descriptions** : priorité à la langue de l'interface (fr), puis en. Si seule une autre langue existe, afficher le texte tel quel avec `synopsisLang` renseigné (jamais de traduction silencieuse). Nettoyer le HTML, couper à 600 caractères sur une fin de phrase.
- **Genres** : correspondre à un vocabulaire fixe (`drame`, `comedie`, `horreur`, `science-fiction`, `aventure`, `documentaire`, `muet`, `animation`…) via une table dans `rules/`. Un genre inconnu est ignoré, pas inventé.
- **Droits** : tout film a un `rights.status`. `unknown` n'est jamais affiché (voir §6).
- **Champ manquant** : `null`, jamais une chaîne vide ni « N/A » dans l'interface. L'UI masque la ligne correspondante.

## 4. Comportement attendu côté utilisateur

1. **Entrée dans Films** : un aperçu immédiat des films **les plus en vogue** (ligne « En vogue »), puis « Nouveautés », « Classiques muets », et les collections éditoriales.
2. **Sélection d'un film** : la fiche s'ouvre, et une ligne **« Films semblables »** se déroule juste en dessous. Elle est prête avant que l'utilisateur descende.
3. **Navigation continue** : choisir un film semblable ouvre sa fiche et sa propre ligne de semblables, sans retour intermédiaire. Le retour arrière remonte l'historique de fiches.
4. **Recherche** : tolérante aux accents et aux fautes légères, résultats groupés par film (une entrée par `canonicalKey`).

### 4.1 Classement « En vogue »

```
score = 0.5 * popularité_normalisée
      + 0.2 * fraîcheur (1 pour <30 jours, décroissance linéaire jusqu'à 0 à 365 jours)
      + 0.2 * qualité (a une affiche, un synopsis, un flux HD, des sous-titres)
      + 0.1 * bonus éditorial (présent dans featured.json)
```

Les éléments de `featured.json` passent en tête dans l'ordre fourni. Les films sans flux lisible sont exclus. Diversité : pas plus de 3 films consécutifs du même genre dominant.

### 4.2 Calcul des « semblables » (local, instantané, hors-ligne)

```
score(a, b) = 3.0 * jaccard(genres)
            + 2.0 * (même réalisateur ? 1 : 0)
            + 1.5 * jaccard(distribution)
            + 1.0 * (|année_a - année_b| <= 10 ? 1 : 0)
            + 0.5 * (pays en commun ? 1 : 0)
            + 0.5 * popularité_b
```

On trie par score décroissant, on retire `a` lui-même et les doublons, on garde 12 résultats. `similar_overrides.json` prime sur le calcul. Si moins de 4 résultats locaux, compléter par `FilmSource.related()` en arrière-plan puis mettre la ligne à jour sans la réordonner brutalement.

## 5. Fluidité (objectifs mesurables)

| Action | Objectif |
|---|---|
| Premier affichage de la ligne « En vogue » (cache) | < 300 ms |
| Ouverture d'une fiche | < 250 ms (données déjà en mémoire) |
| Ligne « semblables » disponible | < 150 ms après l'ouverture |
| Défilement d'une ligne | pas de saccade, 60 i/s sur une box d'entrée de gamme |

Techniques :

- **Cache d'abord** (stale-while-revalidate) : afficher le dernier index local, rafraîchir en arrière-plan, mettre à jour par différence (`DiffCallback` / `ArrayObjectAdapter` avec `replaceAll`) sans recréer la ligne.
- **Index local** : au chargement, construire en mémoire des index `id → Film`, `genre → ids`, `director → ids`, pour calculer les semblables sans réseau.
- **Préchargement** : sur focus d'une carte pendant plus de 400 ms, précharger l'affiche haute définition et le calcul des semblables ; à l'ouverture de la fiche, préparer le lecteur (`ExoPlayer.prepare()` sans lecture) pour un démarrage plus rapide.
- **Images** : vignettes redimensionnées (affiche 2:3 de 252 px de large, 16:9 de 408 px), cache disque 100 Mo, formats WebP quand la source le permet.
- **Pagination** : chaque ligne charge 24 éléments, puis la suite à l'approche de la fin.
- **Tout en coroutines**, sur `Dispatchers.IO`, avec annulation quand la ligne n'est plus visible. Aucune requête réseau sur le fil principal.
- **Connexion lente** : choisir le flux le plus léger si le débit mesuré est faible, et afficher la taille/qualité dans la fiche.

## 6. Droits et sécurité (obligatoire)

- **Filtre de droits à la source** : la requête Internet Archive ne se fait plus sur `mediatype:movies` seul. Restreindre aux collections de `rules/rights.json` et/ou à une licence explicite (`licenseurl` Creative Commons ou domaine public). Tout film sans statut clair est écarté.
- **Mention sur la fiche** : source, licence et lien de preuve (`evidenceUrl`) affichés.
- **Retrait rapide** : `rules/blocklist.json` est appliqué avant tout affichage. Le bouton « Signaler un problème » alimente cette liste.
- **Validation d'un paquet avant application** (échec = on garde le paquet précédent) :
  1. `schema_version` connu et `min_app_version` ≤ version de l'app ;
  2. empreinte SHA-256 de chaque fichier égale à celle de l'index ;
  3. hôtes dans `allowed_hosts`, HTTPS uniquement ;
  4. taille maximale (manifeste ≤ 64 Ko, chaque fichier ≤ 2 Mo) ;
  5. champs obligatoires présents, types corrects ;
  6. aucun champ inconnu qui ressemble à du code (pas de script, pas d'expression évaluée).
- **Recommandé** : signer l'index avec une clé Ed25519 dont la clé publique est dans l'APK.
- Le jeton GitHub ne doit **jamais** figurer dans l'application : les paquets sont lus via GitHub Pages (public).

## 7. Protocole de mise à jour

1. Un fichier `engines/index.json` (publié sur Pages) liste chaque moteur : `engine_id`, `version`, `sha256` du paquet, `url`, `min_app_version`.
2. L'app interroge l'index au lancement puis toutes les 6 h (WorkManager), avec `ETag`/`If-None-Match`.
3. Si la version distante est supérieure : télécharger dans un dossier temporaire, valider (§6), puis **basculer atomiquement** vers `filesDir/engines/films/<version>/` et écrire le pointeur `current`.
4. Conserver la dernière version valide pour un **retour arrière automatique** si l'application échoue au chargement ou si le moteur produit moins de N films.
5. Journaliser localement : version appliquée, date, erreurs de validation (utile pour le diagnostic).
6. Premier lancement hors-ligne : utiliser `seed/films_seed.json` embarqué dans l'APK.

## 8. Rôle de l'agent qui alimente le dépôt

L'agent reçoit des liens et des sources brutes, puis :

1. **lit** `engines/films/README.md` et ce document ;
2. **nettoie et normalise** les données selon le modèle du §3 ;
3. **renseigne les droits** de chaque film avec une preuve ; sans preuve, le film n'est pas ajouté ;
4. **met à jour** `manifest.json` (incrémente `version`, `updated_at`) et `CHANGELOG.md` ;
5. **lance le validateur** `python engines/validate.py films` (à créer, mêmes règles que §6) ;
6. **ouvre une pull request**. La CI vérifie, puis Pages publie l'index.

## 9. Architecture Kotlin conseillée

```kotlin
interface EnginePackManager {
    suspend fun checkForUpdates(): List<EngineId>          // compare index distant et version locale
    suspend fun install(engine: EngineId): InstallResult   // télécharge, valide, bascule, ou rollback
    fun current(engine: EngineId): EnginePack?             // pack actif (ou seed)
}

class FilmEngine(private val packs: EnginePackManager, private val cache: FilmCache) {
    val trending: Flow<List<Film>>
    fun similar(id: String): Flow<List<Film>>              // local d'abord, enrichi ensuite
    suspend fun search(query: String): List<Film>
    suspend fun resolve(id: String): Film?                 // choisit le flux, vérifie les droits et la liste noire
}
```

Chaque moteur futur (TV Direct, Séries, Radio, Podcasts, Jeux…) réutilise `EnginePackManager` (téléchargement, validation, bascule, retour arrière) et n'implémente que sa logique propre :

| Moteur | Particularité à traiter |
|---|---|
| Films | Droits, doublons multi-sources, semblables, tendances |
| Séries | Série → saison → épisode, ordre de lecture, « épisode suivant » |
| TV Direct | Vérification de disponibilité du flux, repli entre flux miroirs, zapping, programme (EPG) |
| Radio / Podcasts | Audio seul, épisodes datés, reprise de lecture, flux de secours |
| Jeux | Empreinte SHA-256 de l'APK, taille, version minimale d'Android |
| Musique | Albums, pistes, files de lecture |

## 10. Critères d'acceptation (moteur Films)

- [ ] Un paquet valide déposé dans `engines/films/` est détecté, validé et appliqué sans mise à jour de l'APK.
- [ ] Un paquet invalide (mauvais SHA, hôte interdit, schéma inconnu) est refusé et l'ancien paquet reste actif.
- [ ] Premier lancement hors-ligne : la ligne « En vogue » s'affiche depuis `seed`.
- [ ] Deux sources fournissant le même film produisent **une seule** fiche.
- [ ] Aucun film à droits `unknown` ou présent dans `blocklist.json` n'est affiché.
- [ ] La ligne « Films semblables » est affichée en moins de 150 ms et fonctionne hors-ligne.
- [ ] Enchaîner 5 fiches de suite via les semblables ne provoque ni écran vide ni rechargement visible.
- [ ] Descriptions nettoyées (sans HTML), langue indiquée, champs absents masqués.
- [ ] Tests unitaires : normalisation de `canonicalKey`, fusion de doublons, score de similarité, validation de paquet, rollback.
- [ ] `assembleDebug` vert, tests Python verts, validateur `engines/validate.py` en CI.

## 11. Ordre de travail

1. Modèle `Film`, normalisation, `canonicalKey` et tests.
2. Filtre de droits dans `InternetArchiveFilmSource` + `rules/rights.json` + `blocklist.json`.
3. `EnginePackManager` : index, téléchargement, validation, bascule atomique, rollback.
4. Manifeste v2 + recettes de source + `seed` embarqué.
5. Index local et calcul des semblables ; ligne « Films semblables » sur la fiche.
6. Classement « En vogue » et collections éditoriales.
7. Préchargement, cache d'images, mesures de fluidité.
8. `engines/validate.py` et job CI, puis documentation de l'agent (`engines/films/README.md`).
