# Interface du lecteur audio et vidéo — MISSA TV 360

Remplace `PlayerActivity` et `activity_player.xml` du dépôt (branche `arena/ca646cf9-missa-tv-360`).
Tous les extras existants (`EXTRA_URL`, `EXTRA_TITLE`, `EXTRA_LIVE`, `EXTRA_AUDIO_ONLY`, `EXTRA_COVER_RES`, `EXTRA_COVER_URL`) sont conservés : le code existant continue de fonctionner.

## Installation

| Fichier du dossier | Destination dans le dépôt |
|---|---|
| `kotlin/playback/PlayerActivity.kt` | `app/src/main/java/com/missa/tv360/playback/PlayerActivity.kt` (remplace) |
| `kotlin/data/WatchProgressStore.kt` | `app/src/main/java/com/missa/tv360/data/WatchProgressStore.kt` (nouveau) |
| `res/layout/activity_player.xml` | `app/src/main/res/layout/` (remplace) |
| `res/layout/missa_player_controls.xml` | `app/src/main/res/layout/` (nouveau) |
| `res/drawable/*.xml` | `app/src/main/res/drawable/` (nouveaux) |
| `res/values/player_colors.xml`, `player_strings.xml` | `app/src/main/res/values/` (nouveaux) |

Les ressources utilisent le préfixe `player_` / `pl_` pour éviter tout doublon avec l'existant.

## Manifeste

Ajouter sur l'activité du lecteur, pour éviter un redémarrage à chaque changement de configuration :

```xml
android:configChanges="keyboard|keyboardHidden|navigation|orientation|screenSize|uiMode"
```

## Appel depuis la fiche (`DetailsFragment`)

```kotlin
startActivity(Intent(requireContext(), PlayerActivity::class.java).apply {
    putExtra(PlayerActivity.EXTRA_URL, video.streamUrl)
    putExtra(PlayerActivity.EXTRA_TITLE, video.title)
    putExtra(PlayerActivity.EXTRA_LIVE, video.isLive)
    putExtra(PlayerActivity.EXTRA_AUDIO_ONLY, video.isAudioOnly)
    putExtra(PlayerActivity.EXTRA_COVER_URL, video.cardUrl)
    putExtra(PlayerActivity.EXTRA_VIDEO_ID, video.id)                     // reprise de lecture
    putExtra(PlayerActivity.EXTRA_SUBTITLE, if (video.isLive) "TV Direct · EN DIRECT" else video.kind.label)
    // Zapping : chaînes voisines de la même ligne
    putExtra(PlayerActivity.EXTRA_ZAP_URLS, channels.map { it.streamUrl }.toTypedArray())
    putExtra(PlayerActivity.EXTRA_ZAP_TITLES, channels.map { it.title }.toTypedArray())
    putExtra(PlayerActivity.EXTRA_ZAP_INDEX, channels.indexOfFirst { it.id == video.id }.coerceAtLeast(0))
})
```

## Comportement

**Vidéo (films, séries)** : progression jaune, ±10 s, lecture/pause, bandeau titre en haut, reprise à la dernière position (entre 3 % et 95 %).
**Direct** : badge LIVE, pas de barre si le flux n'est pas rembobinable, bouton « Revenir au direct » après 15 s de retard, zapping avec Haut/Bas ou CH+/CH−, bandeau du nom de chaîne.
**Audio (radio, podcasts)** : visuel + titre + sous-titre, contrôleur toujours visible, pulsation du visuel pendant la lecture.
**Erreurs** : 3 reconnexions automatiques (2 s, 4 s, 8 s) avec message, puis écran « Lecture impossible » avec Réessayer (focus par défaut) et Retour.
**Économie de données** : `EXTRA_DATA_SAVER = true` limite la vidéo en définition standard.

## À vérifier à la compilation

- `androidx.media3.ui.R.id.exo_rew` / `exo_ffwd` : si l'accès à ces ids échoue avec la configuration R du projet, remplacer par `playerView.findViewById(resources.getIdentifier("exo_rew", "id", packageName))`.
- `ThumbnailLoader.loadArtwork(url) { bitmap -> }` : signature reprise du code existant.
- `bg_player_audio.xml` et les couleurs `player_*` sont dans ce dossier.
