package com.missa.tv360.data

import android.content.Context

/**
 * Mémorise la position de lecture des contenus (films, séries, podcasts) pour « Reprendre ».
 * Stockage local (SharedPreferences) : id -> "position;durée;dateMaj".
 */
object WatchProgressStore {
    private const val PREFS = "watch_progress"
    private const val MIN_FRACTION = 0.03f   // en dessous : on considère que rien n'a été regardé
    private const val MAX_FRACTION = 0.95f   // au-dessus : contenu terminé

    fun save(context: Context, id: String, positionMs: Long, durationMs: Long) {
        if (id.isBlank() || durationMs <= 0L || positionMs < 0L) return
        val fraction = positionMs.toFloat() / durationMs
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (fraction >= MAX_FRACTION) prefs.remove(id)                    // terminé : on oublie
        else prefs.putString(id, "$positionMs;$durationMs;${System.currentTimeMillis()}")
        prefs.apply()
    }

    private fun read(context: Context, id: String): Triple<Long, Long, Long>? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(id, null) ?: return null
        val p = raw.split(';')
        if (p.size != 3) return null
        val pos = p[0].toLongOrNull() ?: return null
        val dur = p[1].toLongOrNull() ?: return null
        val at = p[2].toLongOrNull() ?: return null
        return Triple(pos, dur, at)
    }

    /** Fraction lue entre 0 et 1, ou null si le contenu n'est pas « en cours ». */
    fun fraction(context: Context, id: String): Float? {
        val (pos, dur, _) = read(context, id) ?: return null
        if (dur <= 0L) return null
        val f = pos.toFloat() / dur
        return f.takeIf { it in MIN_FRACTION..MAX_FRACTION }
    }

    /** Position de reprise en ms, ou 0 si le contenu n'est pas « en cours ». */
    fun resumePositionMs(context: Context, id: String): Long =
        if (fraction(context, id) != null) read(context, id)?.first ?: 0L else 0L

    /** Ids « en cours », du plus récent au plus ancien. */
    fun recent(context: Context, limit: Int = 10): List<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all.keys
            .mapNotNull { id -> read(context, id)?.let { id to it.third } }
            .filter { (id, _) -> fraction(context, id) != null }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
}
