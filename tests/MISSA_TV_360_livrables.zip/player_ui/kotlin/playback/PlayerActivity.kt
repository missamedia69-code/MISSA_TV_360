package com.missa.tv360.playback

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.missa.tv360.R
import com.missa.tv360.data.WatchProgressStore
import com.missa.tv360.ui.ThumbnailLoader

/**
 * Lecteur MISSA TV 360 (audio + vidéo) — Media3 ExoPlayer.
 *
 * - Vidéo : contrôleur personnalisé (progression jaune, ±10 s, lecture/pause), bandeau titre,
 *   badge LIVE, « Revenir au direct », zapping haut/bas entre chaînes, reprise de lecture.
 * - Audio : visuel + titre, contrôleur toujours visible, léger effet de pulsation en lecture.
 * - Fiabilité : reconnexion automatique avec attente croissante, puis écran d'erreur (Réessayer / Retour).
 */
class PlayerActivity : AppCompatActivity() {

    companion object {
        // Extras existants (inchangés)
        const val EXTRA_URL = "extra_url"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_LIVE = "extra_live"
        const val EXTRA_AUDIO_ONLY = "extra_audio_only"
        const val EXTRA_COVER_RES = "extra_cover_res"
        const val EXTRA_COVER_URL = "extra_cover_url"

        // Nouveaux extras (tous optionnels)
        const val EXTRA_VIDEO_ID = "extra_video_id"          // active la reprise de lecture
        const val EXTRA_SUBTITLE = "extra_subtitle"          // ex. « TV Direct · EN DIRECT »
        const val EXTRA_ZAP_URLS = "extra_zap_urls"          // String[] : flux des chaînes voisines
        const val EXTRA_ZAP_TITLES = "extra_zap_titles"      // String[] : noms correspondants
        const val EXTRA_ZAP_INDEX = "extra_zap_index"        // Int : position de la chaîne courante
        const val EXTRA_DATA_SAVER = "extra_data_saver"      // Boolean : limite la vidéo en définition standard

        private const val MAX_RETRIES = 3
        private const val SEEK_INCREMENT_MS = 10_000L
        private const val LIVE_BEHIND_THRESHOLD_MS = 15_000L
        private const val BANNER_MS = 2_500L
    }

    // --- état ---
    private var player: ExoPlayer? = null
    private lateinit var url: String
    private var title: String = ""
    private var subtitle: String = ""
    private var videoId: String? = null
    private var isLive = false
    private var isAudio = false
    private var dataSaver = false
    private var zapUrls: Array<String> = emptyArray()
    private var zapTitles: Array<String> = emptyArray()
    private var zapIndex = 0
    private var retryCount = 0
    private var resumeMs = 0L

    // --- vues ---
    private lateinit var playerView: PlayerView
    private lateinit var topOverlay: View
    private lateinit var topTitle: TextView
    private lateinit var topSubtitle: TextView
    private lateinit var topLiveChip: View
    private lateinit var zapBanner: TextView
    private lateinit var bufferingBox: View
    private lateinit var bufferingText: TextView
    private lateinit var errorPanel: View
    private lateinit var errorMessage: TextView
    private lateinit var btnRetry: Button
    private lateinit var audioPanel: View
    private lateinit var audioCover: ImageView
    private lateinit var audioTitle: TextView
    private lateinit var audioSubtitle: TextView

    // --- vues du contrôleur (dans PlayerView) ---
    private lateinit var ctlTimeRow: View
    private lateinit var ctlRew: View
    private lateinit var ctlFfwd: View
    private lateinit var ctlLiveChip: View
    private lateinit var btnGoLive: Button

    private val handler = Handler(Looper.getMainLooper())
    private val hideBanner = Runnable { zapBanner.visibility = View.GONE }
    private val liveTicker = object : Runnable {
        override fun run() {
            updateLiveUi()
            handler.postDelayed(this, 1_000)
        }
    }
    private val pulse: ObjectAnimator by lazy {
        ObjectAnimator.ofPropertyValuesHolder(
            audioCover,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.04f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.04f),
        ).apply {
            duration = 1_600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
        }
    }

    // ------------------------------------------------------------------ cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        val extraUrl = intent.getStringExtra(EXTRA_URL)
        if (extraUrl.isNullOrBlank()) {
            finish()
            return
        }
        url = extraUrl
        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        subtitle = intent.getStringExtra(EXTRA_SUBTITLE).orEmpty()
        videoId = intent.getStringExtra(EXTRA_VIDEO_ID)
        isLive = intent.getBooleanExtra(EXTRA_LIVE, false)
        isAudio = intent.getBooleanExtra(EXTRA_AUDIO_ONLY, false)
        dataSaver = intent.getBooleanExtra(EXTRA_DATA_SAVER, false)
        zapUrls = intent.getStringArrayExtra(EXTRA_ZAP_URLS) ?: emptyArray()
        zapTitles = intent.getStringArrayExtra(EXTRA_ZAP_TITLES) ?: emptyArray()
        zapIndex = intent.getIntExtra(EXTRA_ZAP_INDEX, 0).coerceIn(0, (zapUrls.size - 1).coerceAtLeast(0))

        bindViews()
        enterImmersiveMode()
        bindStaticUi()
        setupAudioMode()

        if (!isLive) {
            videoId?.let { resumeMs = WatchProgressStore.resumePositionMs(this, it) }
        }
    }

    override fun onResume() {
        super.onResume()
        if (player == null) initializePlayer()
        handler.post(liveTicker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(liveTicker)
        handler.removeCallbacks(hideBanner)
        saveProgress()
        releasePlayer()
    }

    // ------------------------------------------------------------------ vues

    private fun bindViews() {
        playerView = findViewById(R.id.player_view)
        topOverlay = findViewById(R.id.top_overlay)
        topTitle = findViewById(R.id.top_title)
        topSubtitle = findViewById(R.id.top_subtitle)
        topLiveChip = findViewById(R.id.top_live_chip)
        zapBanner = findViewById(R.id.zap_banner)
        bufferingBox = findViewById(R.id.buffering_box)
        bufferingText = findViewById(R.id.buffering_text)
        errorPanel = findViewById(R.id.error_panel)
        errorMessage = findViewById(R.id.error_message)
        btnRetry = findViewById(R.id.btn_retry)
        audioPanel = findViewById(R.id.audio_panel)
        audioCover = findViewById(R.id.audio_cover)
        audioTitle = findViewById(R.id.audio_title)
        audioSubtitle = findViewById(R.id.audio_subtitle)

        // Vues du contrôleur personnalisé
        ctlTimeRow = playerView.findViewById(R.id.ctl_time_row)
        ctlRew = playerView.findViewById(androidx.media3.ui.R.id.exo_rew)
        ctlFfwd = playerView.findViewById(androidx.media3.ui.R.id.exo_ffwd)
        ctlLiveChip = playerView.findViewById(R.id.ctl_live_chip)
        btnGoLive = playerView.findViewById(R.id.btn_go_live)

        btnRetry.setOnClickListener { retryNow() }
        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }
        btnGoLive.setOnClickListener {
            player?.seekToDefaultPosition()
            player?.play()
        }

        // Le bandeau du haut suit le contrôleur (toujours visible en mode audio)
        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                topOverlay.visibility = if (isAudio) View.GONE else visibility
            }
        )
    }

    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun bindStaticUi() {
        topTitle.text = title
        topSubtitle.text = subtitle
        topSubtitle.visibility = if (subtitle.isBlank()) View.GONE else View.VISIBLE
        topLiveChip.visibility = if (isLive) View.VISIBLE else View.GONE
        ctlLiveChip.visibility = if (isLive) View.VISIBLE else View.GONE
    }

    private fun setupAudioMode() {
        if (!isAudio) return
        audioPanel.visibility = View.VISIBLE
        audioTitle.text = title
        audioSubtitle.text = subtitle
        audioSubtitle.visibility = if (subtitle.isBlank()) View.GONE else View.VISIBLE
        playerView.setShutterBackgroundColor(Color.TRANSPARENT)
        playerView.controllerShowTimeoutMs = 0          // contrôleur toujours visible
        playerView.controllerHideOnTouch = false
        playerView.post { playerView.showController() }

        val coverRes = intent.getIntExtra(EXTRA_COVER_RES, 0)
        if (coverRes != 0) audioCover.setImageResource(coverRes)
        intent.getStringExtra(EXTRA_COVER_URL)?.takeIf { it.isNotBlank() }?.let { coverUrl ->
            ThumbnailLoader.loadArtwork(coverUrl) { bitmap ->
                if (!isFinishing && !isDestroyed) audioCover.setImageBitmap(bitmap)
            }
        }
    }

    // ------------------------------------------------------------------ lecteur

    private fun initializePlayer() {
        val selector = DefaultTrackSelector(this).apply {
            if (dataSaver) setParameters(buildUponParameters().setMaxVideoSizeSd())
        }
        val attributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(if (isAudio) C.AUDIO_CONTENT_TYPE_MUSIC else C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val exo = ExoPlayer.Builder(this)
            .setTrackSelector(selector)
            .setAudioAttributes(attributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(SEEK_INCREMENT_MS)
            .setSeekForwardIncrementMs(SEEK_INCREMENT_MS)
            .build()

        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> showBuffering(null)
                    Player.STATE_READY -> {
                        retryCount = 0
                        hideBuffering()
                        hideError()
                    }
                    Player.STATE_ENDED -> {
                        hideBuffering()
                        if (!isLive) videoId?.let { WatchProgressStore.save(this@PlayerActivity, it, 1, 1) } // terminé
                    }
                    else -> hideBuffering()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePulse(isPlaying)
            }

            override fun onEvents(player: Player, events: Player.Events) {
                updateControlsForContent(player)
            }

            override fun onPlayerError(error: PlaybackException) {
                handlePlayerError(error)
            }
        })

        playerView.player = exo
        player = exo
        loadMedia(exo, url, if (resumeMs > 0L) resumeMs else C.TIME_UNSET)
    }

    private fun loadMedia(exo: ExoPlayer, streamUrl: String, startMs: Long) {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(subtitle.ifBlank { null })
            .build()
        val builder = MediaItem.Builder().setUri(streamUrl).setMediaMetadata(metadata)
        if (isLive) {
            builder.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(5_000)
                    .setMinPlaybackSpeed(0.97f)
                    .setMaxPlaybackSpeed(1.03f)
                    .build()
            )
        }
        exo.setMediaItem(builder.build(), startMs)
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun releasePlayer() {
        if (pulse.isStarted) pulse.cancel()
        playerView.player = null
        player?.release()
        player = null
    }

    private fun saveProgress() {
        val exo = player ?: return
        val id = videoId ?: return
        if (isLive) return
        val duration = exo.duration
        if (duration == C.TIME_UNSET || duration <= 0L) return
        WatchProgressStore.save(this, id, exo.currentPosition, duration)
        resumeMs = exo.currentPosition
    }

    // ------------------------------------------------------------------ erreurs et reconnexion

    private fun handlePlayerError(error: PlaybackException) {
        val exo = player ?: return
        // Direct : on a pris trop de retard sur la fenêtre HLS, on se recale sur le direct.
        if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            exo.seekToDefaultPosition()
            exo.prepare()
            return
        }
        val isNetwork = error.errorCode in 2000..2999
        if (isNetwork && retryCount < MAX_RETRIES) {
            retryCount++
            showBuffering(getString(R.string.pl_reconnecting, retryCount, MAX_RETRIES))
            val delayMs = 2_000L shl (retryCount - 1)          // 2 s, 4 s, 8 s
            handler.postDelayed({
                player?.let { p ->
                    if (!isLive) p.seekTo(p.currentPosition)
                    p.prepare()
                    p.playWhenReady = true
                }
            }, delayMs)
            return
        }
        showError(
            if (isNetwork) getString(R.string.pl_error_network) else getString(R.string.pl_error_generic)
        )
    }

    private fun retryNow() {
        retryCount = 0
        hideError()
        showBuffering(null)
        player?.let { p ->
            if (isLive) p.seekToDefaultPosition()
            p.prepare()
            p.playWhenReady = true
        }
    }

    private fun showError(message: String) {
        hideBuffering()
        errorMessage.text = message
        errorPanel.visibility = View.VISIBLE
        btnRetry.requestFocus()
    }

    private fun hideError() {
        errorPanel.visibility = View.GONE
    }

    private fun showBuffering(text: String?) {
        bufferingText.text = text.orEmpty()
        bufferingText.visibility = if (text.isNullOrBlank()) View.GONE else View.VISIBLE
        bufferingBox.visibility = View.VISIBLE
    }

    private fun hideBuffering() {
        bufferingBox.visibility = View.GONE
    }

    // ------------------------------------------------------------------ contrôles dynamiques

    /** Adapte le contrôleur au contenu : un direct sans retour en arrière n'a ni barre ni ±10 s. */
    private fun updateControlsForContent(p: Player) {
        val seekable = !isLive || p.isCurrentMediaItemSeekable
        val showSeek = if (seekable) View.VISIBLE else View.GONE
        ctlTimeRow.visibility = showSeek
        ctlRew.visibility = showSeek
        ctlFfwd.visibility = showSeek
    }

    /** Affiche « Revenir au direct » quand on est en retard de plus de 15 s. */
    private fun updateLiveUi() {
        if (!isLive) return
        val p = player ?: return
        val offset = p.currentLiveOffset
        val behind = offset != C.TIME_UNSET && offset > LIVE_BEHIND_THRESHOLD_MS && p.isCurrentMediaItemSeekable
        btnGoLive.visibility = if (behind) View.VISIBLE else View.GONE
    }

    private fun updatePulse(isPlaying: Boolean) {
        if (!isAudio) return
        if (isPlaying) {
            if (pulse.isPaused) pulse.resume() else if (!pulse.isStarted) pulse.start()
        } else if (pulse.isRunning) {
            pulse.pause()
        }
    }

    // ------------------------------------------------------------------ zapping (chaînes en direct)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val canZap = isLive && zapUrls.size > 1 &&
            errorPanel.visibility != View.VISIBLE &&
            !playerView.isControllerFullyVisible
        if (canZap && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(+1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun zap(delta: Int) {
        zapIndex = (zapIndex + delta + zapUrls.size) % zapUrls.size
        url = zapUrls[zapIndex]
        title = zapTitles.getOrNull(zapIndex).orEmpty().ifBlank { title }
        topTitle.text = title
        retryCount = 0
        hideError()
        player?.let { loadMedia(it, url, C.TIME_UNSET) }
        showZapBanner(title)
    }

    private fun showZapBanner(name: String) {
        zapBanner.text = name
        zapBanner.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, BANNER_MS)
    }
}
